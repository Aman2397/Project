package xam.wifianalysis;

import android.bluetooth.le.ScanResult;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Environment;
import android.provider.Telephony;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.DateTimeKeyListener;
import android.view.Menu;
import android.view.MenuItem;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.Serializable;
import java.util.Calendar;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.Calendar;
import java.io.InputStreamReader;
import java.util.Date;
import java.util.List;
import java.util.jar.Manifest;

public class Main2Activity extends AppCompatActivity {
    private Intent i;
    private TextView textView;
    WifiManager wifimanger;
    WifiInfo wifiInfo;
    FileOutputStream outputStream;
    InputStream inputStream;
    File f,contentFile;
    WebView webView;
    Context context;
    Button b;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        b=(Button)findViewById(R.id.button);

        wifimanger = (WifiManager) this.getSystemService(Context.WIFI_SERVICE);
        BroadcastReceiver br = new Main2Activity.MybroadcastReceiver();
        registerReceiver(br, new IntentFilter(wifimanger.SCAN_RESULTS_AVAILABLE_ACTION));
        wifimanger.startScan();

//        f=new File(getExternalFilesDir(null),"WifiStrength");
//         contentFile=new File(f,"info.txt");
//                try {
//            if (!f.exists()) {
//                f.mkdir();
//                contentFile.createNewFile();
//            }
//            if (!contentFile.exists()) {
//                contentFile.createNewFile();
//            }
//
//        }catch (IOException e){e.printStackTrace();}
//        if(!contentFile.exists()){
//            try {
//                contentFile.createNewFile();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
//
//        textView=(TextView)findViewById(R.id.textView);
//        wifimanger = (WifiManager) this.getSystemService(Context.WIFI_SERVICE);
//        stringBuffer=new StringBuffer();
//        if (wifimanger.isWifiEnabled() == true) {
//            wifiInfo = wifimanger.getConnectionInfo();
//            if (wifiInfo != null) {
//                NetworkInfo.DetailedState state = WifiInfo.getDetailedStateOf(wifiInfo.getSupplicantState());
//                if (state == NetworkInfo.DetailedState.CONNECTED || state == NetworkInfo.DetailedState.OBTAINING_IPADDR) {
//                    textView.setText("Writing into file");
//
//                    new Thread(new Runnable() {
//                        @Override
//                        public void run() {
//                            String temp;
//                            int i=0;
//                            Log.v("TEST","Thread is running");
//                            while(i<20) {
//                                temp=" wifi ssid: " + wifiInfo.getSSID() + "\n" +
//                                        " wifi linkspeed: " + wifiInfo.getLinkSpeed() + "\n" +
//                                        " wifi  ip" + wifiInfo.getIpAddress() + "\n" +
//                                        " system time: " + Calendar.getInstance().getTime() + "\n";
//                                stringBuffer.append(temp);/*" wifi ssid: " + wifiInfo.getSSID() + "\n" +
//                                        " wifi linkspeed: " + wifiInfo.getLinkSpeed() + "\n" +
//                                        " wifi  ip" + wifiInfo.getIpAddress() + "\n" +
//                                        " system time: " + Calendar.getInstance().toString() + "\n");*/
//                                try {
//                                    i++;
//                                    Thread.sleep(1000);
//                                } catch (InterruptedException e) {
//                                    e.printStackTrace();
//                                }
//                                Log.v("TEST","After sleep");
//                            }
//                            try{
//                                outputStream = new FileOutputStream(contentFile, true);
//                            //    inputStream=new FileInputStream(contentFile);
//                                String writedata=stringBuffer.toString();
//                                outputStream.write(writedata.getBytes());
//
//                            } catch (FileNotFoundException e) {
//                                e.printStackTrace();
//                            } catch (IOException e) {
//                                e.printStackTrace();
//                            }
//                            try {
//                                outputStream.close();
//                           //     inputStream.close();
//                            } catch (IOException e) {
//                                e.printStackTrace();
//                            }
//                            //writing in file
//                            Intent in=new Intent(Main2Activity.this,Main3Activity.class);
//                            startActivity(in);
//
//
//                        }
//                    }).start();
//
//
//                }
//                }
//            }

    }
    private class MybroadcastReceiver extends BroadcastReceiver {
        StringBuffer stringBuffer=new StringBuffer();


        @Override
        public void onReceive(Context context, Intent intent) {
            List<android.net.wifi.ScanResult> result = wifimanger.getScanResults();
            //stringBuffer.append("/*********************/"+"\n");
            Log.v("here"," "+result.get(0).SSID);
            for(int i=0;i<result.size();i++) {
                stringBuffer.append(result.get(i).SSID+"  Strength : "+ result.get(i).level+" Date: "+ Calendar.getInstance().getTime()+"\n");
            }
            stringBuffer.append("/*********************/");
            Log.v("here","here"+stringBuffer);
            //Writing in to file
            f=new File(getExternalFilesDir(null),"WifiStrength");
            Log.v("here","above content"+stringBuffer);
            contentFile=new File(f,"info.txt");
            try {
            if (!f.exists()) {
                f.mkdir();
                contentFile.createNewFile();
            }
            if (!contentFile.exists()) {
                contentFile.createNewFile();
            }

        }catch (IOException e){e.printStackTrace();}
        if(!contentFile.exists()){
            try {
                contentFile.createNewFile();
            } catch (IOException e) {
                Log.v("here","error1");
                e.printStackTrace();
            }
        }
            String writedata=stringBuffer.toString();
            try{
                outputStream = new FileOutputStream(contentFile, true);
                outputStream.write(writedata.getBytes());
                            } catch (FileNotFoundException e) {
                Log.v("here","error2");
                e.printStackTrace();
                            } catch (IOException e) {
                Log.v("here","error3");
                e.printStackTrace();
                            }
                            try {
                                Log.v("here","try");
                                outputStream.close();
                            } catch (IOException e) {
                                e.printStackTrace();
                           }
                            //writing in file
                           Intent in=new Intent(Main2Activity.this,Main3Activity.class);
                           startActivity(in);
        }//onReceive
    }

    //Myreceive

}

