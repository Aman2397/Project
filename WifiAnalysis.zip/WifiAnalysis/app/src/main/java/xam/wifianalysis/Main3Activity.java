package xam.wifianalysis;

import android.content.Context;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.Buffer;

public class Main3Activity extends AppCompatActivity {
    String content="";
    String line;
    InputStream inputStream;
    TextView contentText;
    String filename="info.txt";
    File f,contentFile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        Log.v("TEST", "Start of activity3");
        contentText=(TextView)findViewById(R.id.Etext);




        //EditText edittext=(EditText)findViewById(R.id.Etext);
        /*

        try {
            FileInputStream fis = openFileInput(filename);
            BufferedReader reader=new BufferedReader(new InputStreamReader(new DataInputStream(fis)));
            while((line=reader.readLine())!=null){
            edittext.append(line);
                edittext.append("\n");
            }
            fis.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        */
        try {
            Log.v("TEST", "1 line");
            File sdcard=Environment.getExternalStorageDirectory();
            File file=new File(getExternalFilesDir(null),"WifiStrength");

            //read txt from file

            StringBuilder text=new StringBuilder();
            BufferedReader br=new BufferedReader(new FileReader(file+"/info.txt"));
            String line;
           // Log.v("TEST", "2 line");


            StringBuffer stringbuffer=new StringBuffer();
            //Log.v("TEST", "Before will");
            while((line=br.readLine())!=null){
                text.append(line+"\n");
            }
            br.close();
            contentText.setText(stringbuffer.toString());

           TextView tv=(TextView)findViewById(R.id.Etext);
            tv.setText(text.toString());
        }catch (IOException io){
            Log.v("TEST", "error"+io.getMessage());
            io.printStackTrace();
        }

    }
/*
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }*/
}
